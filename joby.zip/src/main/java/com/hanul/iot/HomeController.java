package com.hanul.iot;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import common.CommonUtility;
import member.MemberServiceImpl;
import member.MemberVO;


/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired private MemberServiceImpl member;
	@Autowired private CommonUtility common;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model, HttpSession session) {
		/*
		//이미 저장된 비번을 암호화해서 DB에 저장해두기: 나중에 삭제 ------------------
		//모든회원정보 조회
		List<MemberVO> list = member.member_list();
		for(MemberVO vo : list) {
			if( vo.getSocial()!=null ) continue;
			if( vo.getSalt()!=null ) continue;
			//비번 암호화를 위한 솔트 생성
			String salt = common.generateSalt();
			//솔트를 사용해 비번을 암호화
			String pw = common.getEncrypt(vo.getPw(), salt);
			vo.setPw(pw);
			vo.setSalt(salt);
			member.member_change_pw(vo);
		}
		//----------------------------------------------------------------
		*/
		
		session.removeAttribute("category");
		return "home";
	}
	
}
