package location;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LocationVO {
	private int no;
	private String type, name, name_desc, position,post,address;

}
